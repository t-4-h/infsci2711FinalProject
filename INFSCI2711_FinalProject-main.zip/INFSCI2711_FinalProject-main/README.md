# INFSCI2711_FinalProject

## This is the source code for the application currently running at https://pathealy.pythonanywhere.com

### Some notes on what these files do
- app.py is the python file that basically defines the backend of the web application
- the templates folder contains html files that define the pages of the app, loaded with jinja2 templating
- the static folder contains static assets, such as images, javascript files, and css
- db_connectors.py contains the classes that are used to connect to the three databases
- sql_queries contains sql_aggregation.py, which defines SQLite aggregation functions, pokemon_schema.sql, which is an SQL dump of the SQLite database (including definition of all schema, all data, and queries to load the analytical database), and ER diagrams of the database
- mongodb_scripts contains all scripts that define the mongo queries
- neo4j_queries contains neo4j_aggregation.py, which defines the aggregations in neo4j, pokemon-neo4j.dump is a neo4j dump file of the entire database, and the remaining files detail the queries used to generate the data
- data_cleaning is full of scripts and csv files used when gathering the data for this database. For the most part, you can probably ignore it

### Requirements
To run the Flask demo, you need:
- Python 3.x
- Flask (install with "pip install flask")

To use db_connectors.py, you need in addition to the above:
- pip install pymongo
- pip install dnspython
- pip install mysql-connector-python
- pip install neo4j

### How to Run
Open up your terminal/command prompt of choice and navigate to the folder with "app.py"

On Windows, use these commands:
- set FLASK_APP=app.py
- flask run

On Mac/Linux:
- export FLASK_APP=app.py
- flask run

A message will appear telling you what url to connect to in a browser.