from pymongo import MongoClient
import dns
from neo4j import GraphDatabase
import sqlite3

class SQLite_Connector:
    def __init__(self, localdb):
        self.localdb = localdb
    
    def connect(self):
        con = sqlite3.connect(self.localdb)
        return con, con.cursor()

    def select(self, q):
        "Takes in a select statement and returns whatever that query returns"
        con, cur = self.connect()
        cur.execute(q)
        names = list(map(lambda x: x[0], cur.description))
        results = cur.fetchall()
        con.close()
        return names, results

class Neo4j_Connector:
    def __init__(self, host, port, user, password):
        self.user = user
        self.password = password
        self.uri = host #"bolt://{}:{}".format(host, port)
        self.driver = None
        try:
            self.driver = GraphDatabase.driver(self.uri, auth=(user, self.password))
        except Exception as e:
            print(e)
            
    def execute(self, stmt, db=None):
        if self.driver is  None:
            print("Connection not established")
            return
        session = None
        response = None
        try: 
            if db is None:
                session = self.driver.session(database=db)
            else:
                session = self.driver.session() 
            response = list(session.run(stmt))
        except Exception as e:
            print( e)
        finally:
            if session is not None:
                session.close()
        return response
        
    def disconnect(self):
        if self.driver is not None:
            self.driver.close()

class Mongo_Connector:
    def __init__(self, host, user, password):
        self.host = host
        self.user = user
        self.password = password
        self.db = None
        self.client = None
        
    def connect(self, db):
        self.db = db
        try:
            mongo_connection_string = "mongodb://{}:{}@{}/{}?retryWrites=true&w=majority".format(self.user, self.password, self.host, self.db)
            self.client = MongoClient(mongo_connection_string)
            return self.client
        except Exception as e:
            print(e)
            
    def disconnect(self):
        self.client.close()

def test_mongo():
    # pip install pymongo
    # pip install dnspython
    
    mongo_host = "ec2-3-141-16-8.us-east-2.compute.amazonaws.com"
    mongo_user = "final_project_user"
    mongo_pw = "postalNoble1966MidwestVolleyballTank"
    mongo_db = "final_project_db"

    mongo_conn = Mongo_Connector(mongo_host, mongo_user, mongo_pw)
    client = mongo_conn.connect(mongo_db)
    
    #use (create if non-existent) database "final_project_db"
    db = client[mongo_db]
    #use (create if non-existent) collection 'test_collection'
    collection = db['test_collection']
    
    #documents have dictionary format ( directly equivalent to json)
    test = {"author": "test1",
            "text": "Testing!",
            "tags": ["test"]
            }
    #specific method to insert one document and obtain its insertion id
    #similar methods exist like insert_many() directly available from MongoClient objects
    test_id = collection.insert_one(test).inserted_id
    print(test_id)
    
    # PyMongo driver has specific methods  to run different types of queries:
    # Examples of how to use a MongoClient object:
    #https://pymongo.readthedocs.io/en/stable/
    # https://pymongo.readthedocs.io/en/stable/examples/index.html

def test_neo4j():
    #pip install neo4j
    neo4j_host = "ec2-3-141-16-8.us-east-2.compute.amazonaws.com"
    neo4j_port = "7687"
    neo4j_user = 'neo4j'
    neo4j_pw = 'postalNoble1966MidwestVolleyballTank'   
    
    
    neo4j_conn = Neo4j_Connector(neo4j_host, neo4j_port, neo4j_user, neo4j_pw)
    neo4j_conn.execute("SHOW DATABASES")
    
    # RUN ANY QUERY BY PASSING IT AS A PARAMETER TO EXECUTE
    
    neo4j_conn.disconnect()
