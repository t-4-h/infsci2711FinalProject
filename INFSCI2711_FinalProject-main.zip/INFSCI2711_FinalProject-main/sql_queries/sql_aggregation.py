queries = {}
query_names = {}

query_names[1] = "Stats by Trainer"
queries[1] = """SELECT trainer.trainer_name,
					sum(ft.wins) as Total_Wins,
                    (sum(ft.wins) * 100) / (sum(ft.wins) + sum(ft.losses)) as Win_Percentage,
 					sum(ft.losses) as Total_Losses,
 					(sum(ft.losses)* 100) / (sum(ft.wins) + sum(ft.losses)) as Loss_Percentage
                    FROM fact_table AS ft INNER JOIN trainer ON trainer.trainer_id = ft.trainer_ID
					GROUP BY ft.trainer_id;
                    """
query_names[2] = "Stats by Pokemon"            
queries[2] = """SELECT pokemon.pokemon_name,
                         pokemon.total_points,
                         pokemon.HP,
                         pokemon.Attack,
                         pokemon.Defense,
                         pokemon.special_attack,
                         pokemon.special_defense,
                         pokemon.speed,
					sum(ft.wins) as Total_Wins,
                    (sum(ft.wins) * 100) / (sum(ft.wins) + sum(ft.losses)) as Win_Percentage,
 					sum(ft.losses) as Total_Losses,
 					(sum(ft.losses)* 100) / (sum(ft.wins) + sum(ft.losses)) as Loss_Percentage
                    FROM fact_table AS ft INNER JOIN pokemon ON pokemon.pokemon_id = ft.pokemon_id
					GROUP BY ft.pokemon_id;"""
query_names[3] = "Stats by Type"
queries[3] = """SELECT ft.type_id,
					type.type_1,
                    type.type_2,
					sum(ft.wins) as Total_Wins,
                    (sum(ft.wins) * 100) / (sum(ft.wins) + sum(ft.losses)) as Win_Percentage,
 					sum(ft.losses) as Total_Losses,
 					(sum(ft.losses)* 100) / (sum(ft.wins) + sum(ft.losses)) as Loss_Percentage
                    FROM fact_table AS ft INNER JOIN type ON type.type_id = ft.type_id
					GROUP BY ft.type_id;"""

query_names[4] = "Stats by Ability"
queries[4] = """SELECT ability.ability_name,
					sum(ft.wins) as Total_Wins,
                    (sum(ft.wins) * 100) / (sum(ft.wins) + sum(ft.losses)) as Win_Percentage
 					FROM fact_table AS ft INNER JOIN ability ON ability.ability_id = ft.winning_ability_id
					GROUP BY ft.winning_ability_id;"""
query_names[5] = "Stats by Global Type"                    
queries[5] = """SELECT global_type.type_1 as Global_Type,
					sum(ft.wins) as Total_Wins,
                    (sum(ft.wins) * 100) / (sum(ft.wins) + sum(ft.losses)) as Win_Percentage,
 					sum(ft.losses) as Total_Losses,
 					(sum(ft.losses)* 100) / (sum(ft.wins) + sum(ft.losses)) as Loss_Percentage
                    FROM fact_table AS ft INNER JOIN 
                    ( SELECT type.type_id as type_id, type.type_1 as type_1 FROM type ) AS global_type
                    ON global_type.type_id = ft.type_id
					GROUP BY global_type.type_1"""

query_names[6] = "Stats by Family"                    
queries[6] = """SELECT pokemon.family,
					sum(ft.wins) as Total_Wins,
                    (sum(ft.wins) * 100) / (sum(ft.wins) + sum(ft.losses)) as Win_Percentage,
 					sum(ft.losses) as Total_Losses,
 					(sum(ft.losses)* 100) / (sum(ft.wins) + sum(ft.losses)) as Loss_Percentage
                    FROM fact_table AS ft INNER JOIN pokemon ON pokemon.pokemon_id = ft.pokemon_id
					GROUP BY pokemon.family"""


