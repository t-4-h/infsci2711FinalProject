import pandas as pd
pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)

# creating list of redundant types and their replacements
types = pd.read_csv("processed_data/type.csv", index_col=0)
types_len = types.shape[0]
redundant_types = pd.DataFrame(columns = ['redundant_id','replacement_id'])

for index, row in types.iterrows():
    current_type1 = row['type_1']
    current_type2 = row['type_2']
    for i in range(index+1, types_len-1):
        if (types.loc[i, 'type_1'] == current_type1 and types.loc[i, 'type_2'] == current_type2) or (types.loc[i, 'type_2'] == current_type1 and types.loc[i, 'type_1'] == current_type2):
            #print("redundant: ", types.loc[i, 0:2])
            new_row = {'redundant_id':i, 'replacement_id':index}
            redundant_types = redundant_types.append(new_row, ignore_index=True)
#print(redundant_types)

# creating list of type changes that need to be made to pokemon
pokemon = pd.read_csv("processed_data/pokemon.csv", index_col=0)
type_changes = pd.DataFrame(columns = ['pokemon_id', 'old_type_id','new_type_id'])

for index, row in pokemon.iterrows():
    for index2, row2 in redundant_types.iterrows():
        if row['type_id'] == row2['redundant_id']:
            new_row = {'pokemon_id':index, 'old_type_id':row['type_id'], 'new_type_id':row2['replacement_id']}
            type_changes = type_changes.append(new_row, ignore_index=True)
#print(type_changes)

# applying type changes to pokemon
change_count = 0
for index, row in type_changes.iterrows():
    # check that current pokemon type matches redundant type id
    if pokemon.at[row['pokemon_id'], 'type_id'] == row['old_type_id']:
        pokemon.at[row['pokemon_id'], 'type_id'] = row['new_type_id']
        change_count += 1
if change_count == len(type_changes.index):
    print("All pokemon type changes successfully made")
else:
    print("Not all pokemon type changes made")

# cleaning up types table
for index, row in redundant_types.iterrows():
    types.drop([row['redundant_id']], inplace=True)
if redundant_types.shape[0] == (types_len - types.shape[0]):
    print("All redundant types removed from table")
else:
    print("Not all redundant types removed from table")

# exporting to csv
pokemon.to_csv('processed_data/pokemon_cleantypes.csv')
types.to_csv('processed_data/types_clean.csv')
