import requests



def parse_pkmns(family_html):
  

  #split on each pokemon picture
  members = family_html.split("/cdn.bulbagarden.net")

  #remove first item
  members.pop(0)

  
  pkmn_data = ""
  ls_pkmn = []

  #detect subfamilies 
  #if rowspan=3 -> 3 subfamilies, etc.
  span = 0
  if ("rowspan" in family_html):
        #get number of rows
        span = family_html.split('rowspan="')[1]
        span = span.split('"')[0]
        span = int(span)

  tmp = ""

  #Process each family member
  for pkmn in members:
    #Get id from picture static link
    id = ""
    if("MS8.png" in pkmn):
      id = pkmn.split("MS8.png")[0]
      id = id.rsplit("/",1)[1]
    elif("MS6.png" in pkmn):
      id = pkmn.split("MS6.png")[0]
      id = id.rsplit("/",1)[1]
    elif("MSPE.png" in pkmn):
      id = pkmn.split("MSPE.png")[0]
      id = id.rsplit("/",1)[1]
    
    #Get name
    name = pkmn.split("</span></a>\n</td>")[0]
    name = name.rsplit(">", 1)[1]
  
    #update current pokemon data
    pkmn_data += id + ", " + name

    
    #Update current family path before subfamily branches out
    if ("rowspan" in pkmn):
      if (span != 0):
        tmp = pkmn_data

    #If row html tag detected in pkmn
    if ("<tr>\n<td" in pkmn):
      #if span = 0, there's no branches within family, although there might be subfamilies
      #i.e: there's many different forms of Deerling who evolve into different forms of Sawsbuck
  
      if (span == 0):
        pkmn_data += '\n'
        

      #if there is branch within subfamily, create a new line with tmp data for next alternative evolution
      #i.e: Same Eevee branches out into 8 evolutions -> Eevee is first member in each line
      else:
        pkmn_data += '\n'  + tmp

    lv = ""

    #If current pkmn has an evolution
    if ("→" in pkmn):
      lv = pkmn.split("→")[0]
      lv = lv.rsplit(">", 1)[1]
      if (lv == ' '):
        #level with special html format, just capture all
        lv = pkmn.split("→")[0]
        lv = lv.rsplit("<td",1)[1]
        lv = lv.split(">", 1)[1]
      pkmn_data += ", " + lv + ", "
    else:
        pkmn_data += ", "
        
 
  #clean up  data
  for i in pkmn_data.split("\n"):
    if i[:2] == ", ":
      ls_pkmn.append(i[2:])
    else:
      ls_pkmn.append(i)
  #print(pkmn_data)
  return ls_pkmn

def scrape_family_html(html):
  family_list = []

  families = html.split("""</th></tr>\n<tr>""")

  for family in families:
    family = parse_pkmns(family)
    for i in family:
      family_list.append(i)
  return family_list

def families2csv(families):
  f = open("families.csv", 'w')
  f.write('\n'.join(families))
  f.close()


def scrape_bulbapedia_families():
  url = """https://bulbapedia.bulbagarden.net/wiki/List_of_Pok%C3%A9mon_by_evolution_family"""

  ###Important to change user-agent!! Bulbapedia rejects python's user-agent tag

  response = requests.get(url, headers={'User-Agent': 'Mozilla'})
  response = response.text
  
  scraped = scrape_family_html(response)
  families2csv(scraped)
  #for i in scraped:
   # print(i)



scrape_bulbapedia_families()
  
