DELETE FROM fact_table;

INSERT INTO fact_table
SELECT trained_pokemon.trainer_pokemon_id as fact_table_id, 
trained_pokemon.trainer_id, trained_pokemon.pokemon_id, winning_ability, type_id, wins, losses
FROM trained_pokemon, 
(
	SELECT trained_pokemon.trainer_pokemon_id as win_id, count(w.winning_trainer_id) as wins
	FROM trained_pokemon JOIN combat w ON w.winning_pokemon_id=trained_pokemon.pokemon_id
	AND w.winning_trainer_id=trained_pokemon.trainer_id
	GROUP BY trained_pokemon.trainer_id, trained_pokemon.pokemon_id
),
(
	SELECT trained_pokemon.trainer_pokemon_id as loss_id, count(l.losing_trainer_id) as losses
	FROM trained_pokemon JOIN combat l ON l.losing_pokemon_id=trained_pokemon.pokemon_id
	AND l.losing_trainer_id=trained_pokemon.trainer_id 
	GROUP BY trained_pokemon.trainer_id, trained_pokemon.pokemon_id
),
(
	SELECT combat.winning_ability as winning_ability, pokemon.type_id as type_id, combat.winning_pokemon_id as win_ab_pokemon
	FROM combat JOIN pokemon on pokemon.pokemon_id=combat.winning_pokemon_id
	GROUP BY combat.winning_pokemon_id
)
WHERE fact_table_id=win_id
AND fact_table_id=loss_id
AND win_ab_pokemon=trained_pokemon.pokemon_id
GROUP BY fact_table_id;