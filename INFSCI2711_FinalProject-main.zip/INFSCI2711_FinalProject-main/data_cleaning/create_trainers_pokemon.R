# Creates a table linking trainers and their pokemon Each trainer's pokemon
# are taken from the fields 'PID_1', 'PID_2', 'PID_3', and 'PID_4' in 
# 'SyncPairs_Revised.csv' (the trainers table). Text from these fields is
# matched to pokmeon names in 'pokemon_revised_noabilities.csv'. For each match,
# a pokedex id and trainer id are entered as a new row in the 'trainer_pokemon'
# linking table.
# Finally, a new copy of trainer table is made with pokemon and role columns deleted.

trainers = read.csv("Raw Datasets/SyncPairs_Revised.csv")
pokemon = read.csv("pokemon_revised_noabilities.csv")

trainers_pokemon = data.frame()

for (i in 1:nrow(trainers)) {
  pokemon1 = trainers[i,'PID_1']
  pokemon2 = trainers[i,'PID_2']
  pokemon3 = trainers[i,'PID_3']
  pokemon4 = trainers[i,'PID_4']
  
  # adding record for pokemon1
  if (pokemon1 != "") {
    new_record = c(trainers[i,'TRID'], pokemon[pokemon$Name==pokemon1, 'Pokedex'])
    if (length(new_record[2]) == 0) { # checking for match in abilities table
      cat("error at Trainer id# ", i, ", pokemon1")
    }
    trainers_pokemon = rbind(trainers_pokemon, new_record)
  }
  
  # adding record for pokemon2
  if (pokemon2 != "") {
    new_record = c(trainers[i,'TRID'], pokemon[pokemon$Name==pokemon2, 'Pokedex'])
    if (length(new_record[2]) == 0) { # checking for match in abilities table
      cat("error at Trainer id# ", i, ", pokemon2")
    }
    trainers_pokemon = rbind(trainers_pokemon, new_record)
  }
  
  # adding record for pokemon3
  if (pokemon3 != "") {
    new_record = c(trainers[i,'TRID'], pokemon[pokemon$Name==pokemon3, 'Pokedex'])
    if (length(new_record[2]) == 0) { # checking for match in abilities table
      cat("error at Trainer id# ", i, ", pokemon3")
    }
    trainers_pokemon = rbind(trainers_pokemon, new_record)
  }
  
  # adding record for pokemon4
  if (pokemon4 != "") {
    new_record = c(trainers[i,'TRID'], pokemon[pokemon$Name==pokemon4, 'Pokedex'])
    if (length(new_record[2]) == 0) { # checking for match in abilities table
      cat("error at Trainer id# ", i, ", pokemon4")
    }
    trainers_pokemon = rbind(trainers_pokemon, new_record)
  }
}

# adding id column
trainers_pokemon = cbind(c(1:nrow(trainers_pokemon)), trainers_pokemon)
# naming columns
colnames(trainers_pokemon) = c('tp_id', 't_id', 'pokedex')
# exporting trainers_pokemon link table to csv
write.csv(trainers_pokemon, "trainers_pokemon.csv", row.names = FALSE, quote = FALSE)
# creating new copy of trainers csv table without pokemon or role
trainers[, 3:7] <- list(NULL)
colnames(trainers) = c('t_id', 'name')
write.csv(trainers, "trainers.csv", row.names = FALSE, quote = FALSE)
