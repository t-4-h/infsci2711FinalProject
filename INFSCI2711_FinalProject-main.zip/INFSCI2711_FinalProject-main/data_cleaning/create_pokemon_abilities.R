# Creates a table linking pokemon and their abilities. Each pokemon's abilities
# are taken from the fields 'Ability_1', 'Ability_2', and 'Ability_Hidden' in 
# 'Pokemon_Revised.csv'. Text from these fields is matched to ability names in
# abilities.csv. For each match, a pokedex id and ability id is entered as a new
# row in the 'pokemon_abilities' linking table new table.
# Finally, new copy of pokemon table is made with ability columns deleted.

abilities = read.csv("Raw Datasets/abilities.csv")
pokemon = read.csv("Raw Datasets/Pokemon_Revised.csv")

pokemon_abilities = data.frame()

for (i in 1:nrow(pokemon)) {
  ability1 = pokemon[i,'Ability_1']
  ability2 = pokemon[i,'Ability_2']
  ability3 = pokemon[i,'Ability_Hidden']
  
  # adding record for ability1
  if (ability1 != "") {
    new_record = c(pokemon[i,'Pokedex'], abilities[abilities$ability==ability1,'ability_id'])
    if (length(new_record[2]) == 0) { # checking for match in abilities table
      cat("error at Pokedex = ", i, ", ability1")
    }
    pokemon_abilities = rbind(pokemon_abilities, new_record)
  }
  
  # adding record for ability2
  if (ability2 != "") {
    new_record = c(pokemon[i,'Pokedex'], abilities[abilities$ability==ability2,'ability_id'])
    if (length(new_record[2]) == 0) { # checking for match in abilities table
      cat("error at Pokedex = ", i, ", ability2")
    }
    pokemon_abilities = rbind(pokemon_abilities, new_record)
  }
  
  # adding record for ability3
  if (ability3 != "") {
    new_record = c(pokemon[i,'Pokedex'], abilities[abilities$ability==ability3,'ability_id'])
    if (length(new_record[2]) == 0) { # checking for match in abilities table
      cat("error at Pokedex = ", i, ", ability3")
    }
    pokemon_abilities = rbind(pokemon_abilities, new_record)
  }
}

# adding id column
pokemon_abilities = cbind(c(1:nrow(pokemon_abilities)), pokemon_abilities)
# naming columns
colnames(pokemon_abilities) = c('pha_id', 'pokedex', 'ability_id')
# exporting pokemon_ability link table to csv
write.csv(pokemon_abilities, "pokemon_abilities.csv", row.names = FALSE, quote = FALSE)
# creating new copy of pokemon csv table without abilities
pokemon[, 10:12] <- list(NULL)
write.csv(pokemon, "pokemon_revised_noabilities.csv", row.names = FALSE, quote = FALSE)
