def map_pairs(pairs):
  #takes a list of csv pairs data from SyncPairs csv file with format
  #TRID,Trainer,Role,PID_1,PID_2,PID_3,PID_4
  map = {}
  tmp = []

  pkmns = read_pkmns("Pokemon_Revised.csv")


  for pair in pairs:

    if pair[3] in map.keys():
       tmp = map[pair[3]]
       tmp.append(pair[0])
       map[pair[3]] = tmp
    else:
        map[pair[3]] = [pair[0]]

    if pair[4] != '':
      if pair[4] in map.keys():
        tmp = map[pair[4]]
        tmp.append(pair[0])
        map[pair[4]] = tmp
      else:
          map[pair[4]] = [pair[0]]

    if pair[5] != '':
      if pair[5] in map.keys():
        tmp = map[pair[5]]
        tmp.append(pair[0])
        map[pair[5]] = tmp
      else:
          map[pair[5]] = [pair[0]]

    if pair[6] != '\n' and pair[6] != '':
      if pair[6] in map.keys():
        tmp = map[pair[4]]
        tmp.append(pair[0])
        map[pair[4]] = tmp
      else:
          map[pair[6]] = [pair[0]]
  return map

def read_pairs(file):
  f = open(file, 'r')
  lines = f.readlines()
  lines.pop(0)
  csv_lines = []
  for line in lines:
    csv_lines.append(line.split(','))
  return csv_lines

def read_pkmns(file):
  f = open(file, 'r')
  lines = f.readlines()
  lines.pop(0)
  pkmns = {}
  for line in lines:
    #append only ID and name
    tmp = line.split(',')[:2]
    pkmns[tmp[0]] = tmp[1]

  return pkmns

def read_combats(file): 
  #generator function to read file line by line, without loading into memory at once
  header = True
  with open(file) as f:
    for line in f:
      if header:
        header=False
        continue
      yield line.split(',')[2:]
      


def sync_combats(combatsfile, map_pairs):
  #Trainer 1,Trainer 2,First_pokemon,Second_pokemon,Winner 

  pkmns = read_pkmns("Pokemon_Revised.csv")


  #rotate index of selected trainer using the  mod operator like mod(length_of_trainer_list)#not random, but good enough

  i = 0
  #write line by line as we generate data
  with open('Combats_Synced.csv', 'w') as f:
    f.write("Trainer 1,Trainer 2,First_pokemon,Second_pokemon,Winner\n")
    for combat in read_combats("Combats_Revised.csv"):
      
      #get pkmn name
      pkmn1_name = pkmns[combat[0]]

      pkmn2_name = pkmns[combat[1]]
      
      #no trainer data for at least one pokemon fighting
      if pkmn1_name not in map_pairs.keys() or pkmn2_name not in map_pairs.keys():
        continue 

      trainer1 = map_pairs[pkmn1_name][i % len(map_pairs[pkmn1_name])]

      trainer2 = map_pairs[pkmn2_name][i % len(map_pairs[pkmn2_name])]

      synced_combat = trainer1 + ',' + trainer2 + ',' + ','.join(combat)


      f.write(synced_combat)

      i = i + 1

pairs = map_pairs(read_pairs("SyncPairs_Revised.csv"))

sync_combats("Combats_Revised.csv", pairs)
