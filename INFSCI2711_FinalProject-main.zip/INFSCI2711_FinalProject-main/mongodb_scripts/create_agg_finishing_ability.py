from pymongo import MongoClient

class Mongo_Connector:
    def __init__(self, host, user, password):
        self.host = host
        self.user = user
        self.password = password
        self.db = None
        self.client = None
        
    def connect(self, db):
        self.db = db
        try:
            mongo_connection_string = "mongodb://{}:{}@{}/{}?retryWrites=true&w=majority".format(self.user, self.password, self.host, self.db)
            self.client = MongoClient(mongo_connection_string)
            return self.client
        except Exception as e:
            print(e)
            
    def disconnect(self):
        self.client.close()

mongo_host = "ec2-3-141-16-8.us-east-2.compute.amazonaws.com"
mongo_user = "final_project_user"
mongo_pw = "postalNoble1966MidwestVolleyballTank"
mongo_db = "final_project_db"

mongo_conn = Mongo_Connector(mongo_host, mongo_user, mongo_pw)
client = mongo_conn.connect(mongo_db)
db = client[mongo_db]

# grouping wins by winning ability and exporting to 'agg_winning_ability' collection
db.combat.aggregate([
    {'$group': { '_id': '$winning_ability', 'wins': {'$sum': 1} } },
    {'$out': 'agg_winning_ability'}
])

# adding ability names and win percentage to agg_winning_ability
db.agg_winning_ability.aggregate([
        {'$lookup': { 'from': 'ability', 'localField': '_id', 'foreignField': 'ability_id', 'as': 'ability_lookup'}},
        {'$unwind': { 'path': '$ability_lookup'}},
        {'$addFields': { 'ability_name': '$ability_lookup.ability_name', 'win_percent': {'$divide': ['$wins', 1995] }}},
        {'$project': { 'ability_lookup': 0}},
        {'$merge': { 'into': 'agg_winning_ability', 'on': '_id', 'whenMatched': 'merge'} }
    ]
)