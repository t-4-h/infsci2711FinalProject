from pymongo import MongoClient
import dns

class Mongo_Connector:
    def __init__(self, host, user, password):
        self.host = host
        self.user = user
        self.password = password
        self.db = None
        self.client = None
        
    def connect(self, db):
        self.db = db
        try:
            mongo_connection_string = "mongodb://{}:{}@{}/{}?retryWrites=true&w=majority".format(self.user, self.password, self.host, self.db)
            self.client = MongoClient(mongo_connection_string)
            return self.client
        except Exception as e:
            print(e)
            
    def disconnect(self):
        self.client.close()

mongo_host = "ec2-3-141-16-8.us-east-2.compute.amazonaws.com"
mongo_user = "final_project_user"
mongo_pw = "postalNoble1966MidwestVolleyballTank"
mongo_db = "final_project_db"

mongo_conn = Mongo_Connector(mongo_host, mongo_user, mongo_pw)
client = mongo_conn.connect(mongo_db)
db = client[mongo_db]

## WINS ##
# grouping wins from 'type_1' field by global type and exporting to 'agg_global_type' collection
db.agg_type.aggregate(
    [
        {
            '$group': {
                '_id': '$type_1',
                'global_type': {
                    '$first': '$type_1'
                }, 
                'wins_by_global_type_1': {
                    '$sum': '$wins'
                }
            }
        }, {
            '$out': 'agg_global_type'
        }
    ]
)

# grouping wins from 'type_2' field by global type and merging into 'agg_global_type' collection
db.agg_type.aggregate(
    [
        {
            '$group': {
                '_id': '$type_2',
                'wins_by_global_type_2': {
                    '$sum': '$wins'
                }
            }
        }, {
            '$match': {
                '_id': {
                    '$type': 'string'
                }
            }
        }, {
            '$merge': {
                'into': 'agg_global_type',
                'on': '_id',
                'whenMatched': 'merge'
            }
        }
    ]
)

## LOSSES ##
# grouping losses from 'type_1' field by global type and exporting to 'agg_global_type' collection
db.agg_type.aggregate(
    [
        {
            '$group': {
                '_id': '$type_1',
                'losses_by_global_type_1': {
                    '$sum': '$losses'
                }
            }
        }, {
            '$merge': {
                'into': 'agg_global_type',
                'on': '_id',
                'whenMatched': 'merge'
            }
        }
    ]
)

# grouping losses from 'type_2' field by global type and merging into 'agg_global_type' collection
db.agg_type.aggregate(
    [
        {
            '$group': {
                '_id': '$type_2',
                'losses_by_global_type_2': {
                    '$sum': '$losses'
                }
            }
        }, {
            '$match': {
                '_id': {
                    '$type': 'string'
                }
            }
        }, {
            '$merge': {
                'into': 'agg_global_type',
                'on': '_id',
                'whenMatched': 'merge'
            }
        }
    ]
)

# summing global_type win and loss values from type_1 and type_2, adding win/loss percentages
db.agg_global_type.aggregate(
    [
        {
            '$addFields': {
                'wins': {
                    '$add': [
                        { # ifNull replaces null values with 0's
                            '$ifNull': ['$wins_by_global_type_1', 0]
                        }, {
                            '$ifNull': ['$wins_by_global_type_2', 0] 
                        }
                    ]
                },
                'losses': {
                    '$add': [
                        {
                            '$ifNull': ['$losses_by_global_type_1', 0]
                        }, {
                            '$ifNull': ['$losses_by_global_type_2', 0]
                        }
                    ]
                },
            }
        }, {
            '$project': {
                'losses_by_global_type_1': 0,
                'losses_by_global_type_2': 0,
                'wins_by_global_type_1': 0,
                'wins_by_global_type_2': 0
            }
        }, {
            '$merge': {
                'into': 'agg_global_type',
                'on': '_id',
                'whenMatched': 'replace'
            }
        }
    ]
)

# adding win/loss percentages
db.agg_global_type.aggregate(
    [
        {
            '$addFields': {
                'win_percent': {
                    '$divide': ['$wins', {
                        '$add': ['$wins', '$losses']
                    }]
                },
                'loss_percent': {
                    '$divide': ['$losses', {
                        '$add': ['$wins', '$losses']
                    }]
                }
            }
        }, {
            '$merge': {
                'into': 'agg_global_type',
                'on': '_id',
                'whenMatched': 'merge'
            }
        }
    ]
)