from pymongo import MongoClient

class Mongo_Connector:
    def __init__(self, host, user, password):
        self.host = host
        self.user = user
        self.password = password
        self.db = None
        self.client = None
        
    def connect(self, db):
        self.db = db
        try:
            mongo_connection_string = "mongodb://{}:{}@{}/{}?retryWrites=true&w=majority".format(self.user, self.password, self.host, self.db)
            self.client = MongoClient(mongo_connection_string)
            return self.client
        except Exception as e:
            print(e)
            
    def disconnect(self):
        self.client.close()

mongo_host = "ec2-3-141-16-8.us-east-2.compute.amazonaws.com"
mongo_user = "final_project_user"
mongo_pw = "postalNoble1966MidwestVolleyballTank"
mongo_db = "final_project_db"

mongo_conn = Mongo_Connector(mongo_host, mongo_user, mongo_pw)
client = mongo_conn.connect(mongo_db)
db = client[mongo_db]
#collection = db['test_collection']

db.agg_pokemonname.aggregate(
[
    {
        '$lookup': {
            'from': 'pokemon', 
            'localField': '_id', 
            'foreignField': 'pokemon_id', 
            'as': 'pokemon_stats'
        }
    }, {
        '$unwind': {
            'path': '$pokemon_stats', 
            'preserveNullAndEmptyArrays': True
        }
    }, {
        '$addFields': {
            'total_points': '$pokemon_stats.total_points', 
            'HP': '$pokemon_stats.HP', 
            'attack': '$pokemon_stats.attack', 
            'defense': '$pokemon_stats.defense', 
            'special_attack': '$pokemon_stats.special_attack', 
            'special_defense': '$pokemon_stats.special_defense', 
            'speed': '$pokemon_stats.speed'
        }
    }, {
        '$project': {
            'pokemon_stats': 0
        }
    }, {
        '$merge': {
            'into': 'agg_pokemon_stats', 
            'on': '_id', 
            'whenMatched': 'replace'
        }
    }
]
    )