from pymongo import MongoClient
import dns

class Mongo_Connector:
    def __init__(self, host, user, password):
        self.host = host
        self.user = user
        self.password = password
        self.db = None
        self.client = None
        
    def connect(self, db):
        self.db = db
        try:
            mongo_connection_string = "mongodb://{}:{}@{}/{}?retryWrites=true&w=majority".format(self.user, self.password, self.host, self.db)
            self.client = MongoClient(mongo_connection_string)
            return self.client
        except Exception as e:
            print(e)
            
    def disconnect(self):
        self.client.close()

mongo_host = "ec2-3-141-16-8.us-east-2.compute.amazonaws.com"
mongo_user = "final_project_user"
mongo_pw = "postalNoble1966MidwestVolleyballTank"
mongo_db = "final_project_db"

mongo_conn = Mongo_Connector(mongo_host, mongo_user, mongo_pw)
client = mongo_conn.connect(mongo_db)
db = client[mongo_db]

# grouping wins by type and exporting to 'agg_type' collection
db.combat.aggregate(
    [
        {
            '$lookup': {
                'from': 'pokemon', 
                'localField': 'winning_pokemon_id', 
                'foreignField': 'pokemon_id', 
                'as': 'winning_pokemon_lookup'
            }
        }, {
            '$unwind': {
                'path': '$winning_pokemon_lookup', 
                'preserveNullAndEmptyArrays': False
            }
        }, {
            '$addFields': {
                'type_id': '$winning_pokemon_lookup.type_id', 
            }
        }, {
            '$group': {
                '_id': '$type_id', 
                'wins': {
                    '$sum': 1
                }
            }
        }, {
            '$merge': {
                'into': 'agg_type',
                'on': '_id',
                'whenMatched': 'merge'
            }
        }
    ]
)

# grouping losses by type and merging into 'agg_type' collection
db.combat.aggregate(
    [
        {
            '$lookup': {
                'from': 'pokemon', 
                'localField': 'losing_pokemon_id', 
                'foreignField': 'pokemon_id', 
                'as': 'losing_pokemon_lookup'
            }
        }, {
            '$unwind': {
                'path': '$losing_pokemon_lookup', 
                'preserveNullAndEmptyArrays': False
            }
        }, {
            '$addFields': {
                'type_id': '$losing_pokemon_lookup.type_id'
            }
        }, {
            '$group': {
                '_id': '$type_id', 
                'losses': {
                    '$sum': 1
                }
            }
        }, {
            '$merge': {
                'into': 'agg_type',
                'on': '_id',
                'whenMatched': 'merge'
            }
        }
    ]
)

# adding type names, win/loss percentages to agg_type
db.agg_type.aggregate([
        {
            '$lookup': {
                'from': 'type',
                'localField': '_id',
                'foreignField': 'type_id',
                'as': 'type_lookup'
            }
        }, {
            '$unwind': {
                'path': '$type_lookup',
                'preserveNullAndEmptyArrays': True
            }
        }, {
            '$addFields': {
                'type_id': '$type_lookup.type_id',
                'type_1': '$type_lookup.type_1',
                'type_2': '$type_lookup.type_2',
                'win_percent': {
                    '$divide': ['$wins', {
                        '$add': ['$wins', '$losses']
                    }]
                },
                'loss_percent': {
                    '$divide': ['$losses', {
                        '$add': ['$wins', '$losses']
                    }]
                },
            }
        }, {
            '$project': {
                'type_lookup': 0
            }
        }, {
            '$merge': {
                'into': 'agg_type',
                'on': '_id',
                'whenMatched': 'replace'
            }
        }
    ]
)