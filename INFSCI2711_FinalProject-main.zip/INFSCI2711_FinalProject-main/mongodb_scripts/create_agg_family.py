from pymongo import MongoClient

class Mongo_Connector:
    def __init__(self, host, user, password):
        self.host = host
        self.user = user
        self.password = password
        self.db = None
        self.client = None
        
    def connect(self, db):
        self.db = db
        try:
            mongo_connection_string = "mongodb://{}:{}@{}/{}?retryWrites=true&w=majority".format(self.user, self.password, self.host, self.db)
            self.client = MongoClient(mongo_connection_string)
            return self.client
        except Exception as e:
            print(e)
            
    def disconnect(self):
        self.client.close()

mongo_host = "ec2-3-141-16-8.us-east-2.compute.amazonaws.com"
mongo_user = "final_project_user"
mongo_pw = "postalNoble1966MidwestVolleyballTank"
mongo_db = "final_project_db"

mongo_conn = Mongo_Connector(mongo_host, mongo_user, mongo_pw)
client = mongo_conn.connect(mongo_db)
db = client[mongo_db]
#collection = db['test_collection']


db.combat.aggregate(
     [
    {
        '$lookup': {
            'from': 'pokemon', 
            'localField': 'winning_pokemon_id', 
            'foreignField': 'pokemon_id', 
            'as': 'pokemon_lookup'
        }
    }, {
        '$unwind': {
            'path': '$pokemon_lookup', 
            'preserveNullAndEmptyArrays': True
        }
    }, {
        '$addFields': {
            'family': '$pokemon_lookup.family'
        }
    }, {
        '$project': {
            'pokemon_lookup': 0
        }
    }, {
        '$group': {
            '_id': '$family', 
            'wins': {
                '$sum': 1
            }
        }
    }, {
        '$merge': {
            'into': 'agg_family', 
            'on': '_id', 
            'whenMatched': 'merge'
        }
    }
]
)

db.combat.aggregate(
[
    {
        '$lookup': {
            'from': 'pokemon', 
            'localField': 'losing_pokemon_id', 
            'foreignField': 'pokemon_id', 
            'as': 'pokemon_lookup'
        }
    }, {
        '$unwind': {
            'path': '$pokemon_lookup', 
            'preserveNullAndEmptyArrays': True
        }
    }, {
        '$addFields': {
            'family': '$pokemon_lookup.family'
        }
    }, {
        '$project': {
            'pokemon_lookup': 0
        }
    }, {
        '$group': {
            '_id': '$family', 
            'losses': {
                '$sum': 1
            }
        }
    }, {
        '$merge': {
            'into': 'agg_family', 
            'on': '_id', 
            'whenMatched': 'merge'
        }
    }
]
    )


db.agg_family.aggregate(
[
    {
        '$addFields': {
            'win_percent': {
                '$divide': [
                    '$wins', {
                        '$add': [
                            '$wins', '$losses'
                        ]
                    }
                ]
            }, 
            'loss_percent': {
                '$divide': [
                    '$losses', {
                        '$add': [
                            '$wins', '$losses'
                        ]
                    }
                ]
            }
        }
    }
]
    )
