from pymongo import MongoClient
import pprint

class Mongo_Connector:
    def __init__(self, host, user, password):
        self.host = host
        self.user = user
        self.password = password
        self.db = None
        self.client = None
        
    def connect(self, db):
        self.db = db
        try:
            mongo_connection_string = "mongodb://{}:{}@{}/{}?retryWrites=true&w=majority".format(self.user, self.password, self.host, self.db)
            self.client = MongoClient(mongo_connection_string)
            return self.client
        except Exception as e:
            print(e)
            
    def disconnect(self):
        self.client.close()

mongo_host = "ec2-3-141-16-8.us-east-2.compute.amazonaws.com"
mongo_user = "final_project_user"
mongo_pw = "postalNoble1966MidwestVolleyballTank"
mongo_db = "final_project_db"

mongo_conn = Mongo_Connector(mongo_host, mongo_user, mongo_pw)
client = mongo_conn.connect(mongo_db)
db = client[mongo_db]

### queries on aggregation collections ###

## trainer ##

def winloss_by_trainer():
    result = client['final_project_db']['agg_trainer'].find()
    return result
    # for doc in result:
    #     pprint.pprint(doc)

    # find() returns a Cursor instance, which allows us to iterate over all matching documents
    # https://pymongo.readthedocs.io/en/stable/tutorial.html#querying-for-more-than-one-document
    # find() docs: https://pymongo.readthedocs.io/en/stable/api/pymongo/collection.html?highlight=find()#pymongo.collection.Collection.find

def winloss_by_trainer_filter(trainer_input):
    filter={
    'trainer_name': trainer_input
    }
    result = client['final_project_db']['agg_trainer'].find(
        filter=filter
    )
    return result
# x = winloss_by_trainer('Serena')
# for doc in x:
#   pprint.pprint(doc)


## type ##

def winloss_by_type():
    result = client['final_project_db']['agg_type'].find()
    return result

# two options for winloss_by_type: (1) input as type_name combination, (2) input as typeid
def winloss_by_typecombo_filter(types_input):
    filter={
    'type_1': types_input[0],
    'type_2': types_input[1]
    }
    result = client['final_project_db']['agg_type'].find(
        filter=filter
    )
    return result
#winloss_by_typecombo_filter(['psychic', 'ghost'])

def winloss_by_typeid_filter(typeid_input):
    filter={
    '_id': typeid_input
    }
    result = client['final_project_db']['agg_type'].find(
        filter=filter
    )
    return result


## global type ##

def winloss_by_globaltype():
    result = client['final_project_db']['agg_global_type'].find()
    return result

def winloss_by_globaltype_filter(type_input):
    filter={
    'global_type': type_input
    }
    result = client['final_project_db']['agg_global_type'].find(
        filter=filter
    )
    return result


## winning ability ##

def winloss_by_winningability():
    result = client['final_project_db']['agg_winning_ability'].find()
    return result

def winloss_by_winningability_filter(ability_input):
    filter={
    'ability_name': ability_input
    }
    result = client['final_project_db']['agg_winning_ability'].find(
        filter=filter
    )
    return result


## pokemon (with stats) ##

def winloss_by_pokemon():
    result = client['final_project_db']['agg_pokemon_stats'].find()
    return result

def winloss_by_pokemon_filter(pokemon_input):
    filter={
    'pokemon_name': pokemon_input
    }
    result = client['final_project_db']['agg_pokemon_stats'].find(
        filter=filter
    )
    return result


## pokemon family ##

def winloss_by_pokemonfamily():
    result = client['final_project_db']['agg_pokemon_family'].find()
    return result