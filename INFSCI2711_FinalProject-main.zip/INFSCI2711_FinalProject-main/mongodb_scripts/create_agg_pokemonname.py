from pymongo import MongoClient

class Mongo_Connector:
    def __init__(self, host, user, password):
        self.host = host
        self.user = user
        self.password = password
        self.db = None
        self.client = None
        
    def connect(self, db):
        self.db = db
        try:
            mongo_connection_string = "mongodb://{}:{}@{}/{}?retryWrites=true&w=majority".format(self.user, self.password, self.host, self.db)
            self.client = MongoClient(mongo_connection_string)
            return self.client
        except Exception as e:
            print(e)
            
    def disconnect(self):
        self.client.close()

mongo_host = "ec2-3-141-16-8.us-east-2.compute.amazonaws.com"
mongo_user = "final_project_user"
mongo_pw = "postalNoble1966MidwestVolleyballTank"
mongo_db = "final_project_db"

mongo_conn = Mongo_Connector(mongo_host, mongo_user, mongo_pw)
client = mongo_conn.connect(mongo_db)
db = client[mongo_db]
#collection = db['test_collection']


db.combat.aggregate(
[
    {
        '$group': {
            '_id': '$winning_pokemon_id', 
            'wins': {
                '$sum': 1
            }
        }
    }, 
        {
        '$sort': {
            'Pokemon_name': 1
        }
    },
        {
        '$merge': {
            'into': 'agg_pokemonname', 
            'on': '_id', 
            'whenMatched': 'merge'
        }
    }
]
)

db.combat.aggregate(
   [
    {
        '$group': {
            '_id': '$losing_pokemon_id', 
            'losses': {
                '$sum': 1
            }
        }
    }, 
        {
        '$sort': {
            'Pokemon_name': 1
        }
    },
        {
        '$merge': {
            'into': 'agg_pokemonname', 
            'on': '_id', 
            'whenMatched': 'merge'
        }
    }
]
)

db.agg_pokemonname.aggregate(
[
    {
        '$lookup': {
            'from': 'pokemon', 
            'localField': '_id', 
            'foreignField': 'pokemon_id', 
            'as': 'pokemon_lookup'
        }
    }, {
        '$unwind': {
            'path': '$pokemon_lookup', 
            'preserveNullAndEmptyArrays': True
        }
    },  {
        '$project': {
            'wins': {
                '$ifNull': ['$wins', 0]
            },
            'losses': {
                '$ifNull': ['$losses', 0]
            }
        }
    },
        {
        '$addFields': {
            'pokemon_name': '$pokemon_lookup.pokemon_name', 
            'win_percent': {
                '$divide': [
                    '$wins', {
                        '$add': [
                            '$wins', '$losses'
                        ]
                    }
                ]
            }, 
            'loss_percent': {
                '$divide': [
                    '$losses', {
                        '$add': [
                            '$wins', '$losses'
                        ]
                    }
                ]
            }
        }
    }, {
        '$project': {
            'pokemon_lookup': 0
        }
    }, {
        '$merge': {
            'into': 'agg_pokemonname', 
            'on': '_id', 
            'whenMatched': 'merge'
        }
    }
]
)