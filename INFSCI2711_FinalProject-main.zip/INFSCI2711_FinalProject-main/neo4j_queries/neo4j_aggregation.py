###NOTE: QUERY 4: only water??
###NOTE: QUERY 6: Only water??
###NOTE: win percents of wins/total_battles_in_dataset instead of percent of wins/battles_fought?? we always divide by 1995

queries = {}
query_names = {1: 'Stats by Trainer', 2: 'Stats by Pokemon', 3:'Stats by  Type', 4: 'Stats by Ability', 5: 'Stats by Global Type', 6: 'Stats by Family'}

queries[1] = """MATCH (ft:Fact),(t:Trainer) 

WHERE t.trainer_id = ft.trainer_id

WITH t.trainer_name as trainer, sum(ft.losses) as losses, sum(ft.wins) as wins

RETURN trainer, wins, (wins / 1995.0) * 100.0 as percent_win, losses, (losses / 1995.0) * 100.0 as percent_loss"""

queries[2] = """MATCH (ft:Fact),(p:Pokemon) 

WHERE p.pokemon_id = ft.pokemon_id

WITH p.pokemon_name as pokemon, sum(ft.losses) as losses, sum(ft.wins) as wins,  p.HP as HP, p.attack as attack, p.defense as defense, p.special_attack as special_attack, p.special_defense as special_defense, p.speed as speed

RETURN pokemon, wins, (wins / 1995.0) * 100.0 as percent_win, losses, (losses / 1995.0) * 100.0 as percent_loss, HP, attack, defense, special_attack, special_defense, speed"""

queries[3] = """MATCH (ft:Fact),(t:Type) 

WHERE t.type_id = ft.type_id

WITH t.type_id as type_id, t.type_1 as type_1, t.type_2 as type_2, sum(ft.losses) as losses, sum(ft.wins) as wins

RETURN type_id, type_1, type_2, wins, (wins / 1995.0) * 100.0 as percent_win, losses, (losses / 1995.0) * 100.0 as percent_loss"""



queries[4] = """MATCH (ft:Fact),(a:Ability) 

WHERE ft.winning_ability_id = a.ability_id

WITH a.ability_name as ability, sum(ft.losses) as losses, sum(ft.wins) as wins

RETURN ability, wins, (wins / 1995.0) * 100.0 as percent_win, losses, (losses / 1995.0) * 100.0 as percent_loss"""


queries[5] = """MATCH (ft:Fact),(t:Type)

WHERE ft.type_id = t.type_id and (t.type_1 = "water" or t.type_2 = "water")

WITH sum(ft.losses) as losses, sum(ft.wins) as wins

RETURN sum(wins), (sum(wins)/ 1995.0) * 100.0 as percent_win, sum(losses), (sum(losses) / 1995.0) * 100.0 as percent_loss"""


queries[6] = """MATCH (ft:Fact),(p:Pokemon),(f:Family)<-[:IN_FAMILY]-(p)

WHERE ft.pokemon_id = p.pokemon_id

WITH f.family_name as family, sum(ft.losses) as losses, sum(ft.wins) as wins

RETURN family, wins, (wins / 1995.0) * 100.0 as percent_win, losses, (losses / 1995.0) * 100.0 as percent_loss"""
