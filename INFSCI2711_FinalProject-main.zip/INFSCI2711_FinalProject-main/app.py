from flask import Flask, request, session, url_for, redirect, render_template, abort, g, flash, _app_ctx_stack

import json
import time
import db_connectors

from sql_queries import sql_aggregation
from neo4j_queries import neo4j_aggregation

app = Flask(__name__)
app.secret_key = b'_5#y2L"F4Q8z\n\xec]/'

@app.route('/')
def home_page():
	db_type = 'sql'
	if request.args.get('db_type'):
		db_type = request.args.get('db_type')
	return render_template('home.html', db_type=db_type)

def clean_content(content, keys):
	cleaned = []
	for row in content:
		r = []
		dont_append = False
		for i in range(len(row)):
			if row[i] == None or row[i] == 'None':
				if keys[i] == 'type_2':#unique to this problem
					r.append('')
				else:
					dont_append = True
			else:
				if type(row[i]) == type('str'):
					r.append(row[i])
				else:
					r.append(row[i])
		if not dont_append:
			cleaned.append(r)
	return cleaned

def sort_by(content, keys, col, reverse=False):
	ind = 0
	for i in range(len(keys)):
		if keys[i] == col:
			ind = i

	content.sort(key = lambda x: x[ind])
	if reverse:
		content.reverse()
	return content

@app.route('/browse')
def browse_query():
	start_time = time.time()
	db_type = 'sql'
	if request.args.get('db_type'):
		db_type = request.args.get('db_type')

	table = 'pokemon'
	if request.args.get('table'):
		table = request.args.get('table')

	order = None
	if request.args.get('order'):
		order = json.loads(request.args.get('order'))

	if db_type == 'neo4j':
		# TODO: query for table
		# set keys & contents
		# keys is a list/tuple of column headers
		# contents is a list of lists
		neo4j_host = "neo4j+s://0ddaf65d.databases.neo4j.io"
		neo4j_port = "7687"
		neo4j_user = 'neo4j'
		neo4j_pw = '041h2byIAjIIpZMZYO-KU4VqT-b-Gi3xHfCLx1YUqFs'
		neo4j_conn = db_connectors.Neo4j_Connector(neo4j_host, neo4j_port, neo4j_user, neo4j_pw)

		table_names = {'pokemon': 'Pokemon', 'ability': 'Ability', 'combat': 'Combat', 'pokemon_ability': 'Pokemon_Ability', 'trained_pokemon': 'Trainer_Pokemon', 'trainer': 'Trainer', 'type': 'Type'}
		#RUN QUERY
		query = "MATCH (p: " + table_names[table] + ") RETURN p;"
		try:
			collection = neo4j_conn.execute(query)
		except:
			return redirect('/')

		keys = list(vars(collection[0]['p'])['_properties'].keys())

		contents = []

		for r in collection:
			row = []
			for k in keys: #['p']['properties']
				row.append(vars(r['p'])['_properties'][k])
			contents.append(row)
	elif db_type =='mongo':
		term = table
		if table == 'trained_pokemon':
			term = 'trainer_pokemon'

		con = db_connectors.Mongo_Connector("ec2-3-141-16-8.us-east-2.compute.amazonaws.com", "final_project_user", "postalNoble1966MidwestVolleyballTank")
		client = con.connect("final_project_db")
		collection = client['final_project_db'][term].find()

		keys = list(collection[0].keys())
		for r in collection:
			i = 0
			for k in r.keys():
				if k not in keys:
					keys.insert(i, k)
				i = i + 1
		keys.remove('_id')

		contents = []
		collection = client['final_project_db'][term].find()
		for r in collection:
			row = []
			for k in keys:
				if k in r:
					row.append(r[k])
				else:
					row.append(None)
			contents.append(row)
	else:
		# run the query based on the specifications in the query string
		# keys contains column names, contents is rows
		sql_con = db_connectors.SQLite_Connector('data.db')
		keys, contents = sql_con.select("""SELECT * from """ + table + """;""")

	contents = clean_content(contents, keys)
	if order is not None and order != 'null':
		contents = sort_by(contents, keys, order[0], reverse=(order[1]=='DESC'))

	flash("Browsing " + str(table))
	flash("Elapsed wall-clock time: " + str(time.time() - start_time) + " seconds.")

	return render_template('browse.html', table=table, keys=keys, contents=contents, order=order, db_type=db_type)

@app.route('/aggregation/<q_num>')
def aggregation(q_num):
	start_time = time.time()
	db_type = 'sql'
	if request.args.get('db_type'):
		db_type = request.args.get('db_type')

	order = None
	if request.args.get('order'):
		order = json.loads(request.args.get('order'))

	if db_type == 'mongo':
		agg_names = {1: 'Wins by Trainer', 2: 'Wins by Type', 3:'Wins by Global Type', 4: 'Winning Abilities', 5: 'Wins by Pokemon', 6: 'Wins by Family'}
		query_name = agg_names[int(q_num)]
		mongo_aggs = {1: 'agg_trainer', 2: 'agg_type', 3:'agg_global_type', 4:'agg_winning_ability', 5:'agg_pokemon_stats', 6: 'agg_pokemon_family'}
		con = db_connectors.Mongo_Connector("ec2-3-141-16-8.us-east-2.compute.amazonaws.com", "final_project_user", "postalNoble1966MidwestVolleyballTank")
		client = con.connect("final_project_db")
		collection = client['final_project_db'][mongo_aggs[int(q_num)]].find()

		keys = list(collection[0].keys())
		for r in collection:
			i = 0
			for k in r.keys():
				if k not in keys:
					keys.insert(i, k)
				i = i + 1
		keys.remove('_id')

		contents = []
		collection = client['final_project_db'][mongo_aggs[int(q_num)]].find() # change

		for r in collection:
			row = []
			for k in keys:
				if k in r:
					row.append(r[k])
				else:
					row.append(None)
			contents.append(row)
		header = keys
		result = contents
	elif db_type == 'neo4j':
		neo4j_host = "neo4j+s://0ddaf65d.databases.neo4j.io"
		neo4j_port = "7687"
		neo4j_user = 'neo4j'
		neo4j_pw = '041h2byIAjIIpZMZYO-KU4VqT-b-Gi3xHfCLx1YUqFs'
		neo4j_conn = db_connectors.Neo4j_Connector(neo4j_host, neo4j_port, neo4j_user, neo4j_pw)
		#RUN QUERY
		query = neo4j_aggregation.queries[int(q_num)]
		query_name = neo4j_aggregation.query_names[int(q_num)]
		collection = neo4j_conn.execute(query)
		agg_names = neo4j_aggregation.query_names

		keys = vars(collection[0])['_Record__keys']

		contents = []

		for r in collection:
			row = []
			for k in r:
				row.append(k)
			contents.append(row)
		header = keys
		result = contents
	else:
		con = db_connectors.SQLite_Connector('data.db')
		#con.execute_sqlfile("data_cleaning/populate_fact_table.sql")
		query = sql_aggregation.queries[int(q_num)]
		query_name = sql_aggregation.query_names[int(q_num)]
		header, result = con.select(query)
		agg_names = sql_aggregation.query_names

	result = clean_content(result, header)
	if order is not None and order != 'null':
		result = sort_by(result, header, order[0], reverse=(order[1]=='DESC'))

	flash("Elapsed wall-clock time: " + str(time.time() - start_time) + " seconds.")

	return render_template("aggregation.html", rows = result, header=header, query_name=query_name, order=order, aggregation_names=agg_names, agg_num=int(q_num), db_type=db_type)
